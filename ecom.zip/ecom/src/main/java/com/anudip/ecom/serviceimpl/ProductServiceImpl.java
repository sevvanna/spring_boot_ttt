package com.anudip.ecom.serviceimpl;

import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Optional;

//import org.apache.el.stream.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.anudip.ecom.entity.OrderDetails;
import com.anudip.ecom.entity.Product;
import com.anudip.ecom.entity.Store;
import com.anudip.ecom.exception.OrderCancellationException;
import com.anudip.ecom.exception.ResourceNotFoundException;
import com.anudip.ecom.repository.OrderRepository;
import com.anudip.ecom.repository.ProductRepository;
import com.anudip.ecom.repository.StoreRepository;
import com.anudip.ecom.service.ProductService;

@Service
public class ProductServiceImpl implements ProductService  {
	
	@Autowired
	ProductRepository productRepository;
	@Autowired
	StoreRepository storeRepository;
	@Autowired
	OrderRepository orderRepository;
	

	@Override
	public Product createProduct(Product prod) {
		// TODO Auto-generated method stub
		return productRepository.save(prod);
	}

	@Override
	public Product updateProduct(Product prod1, int prodid) {
		Product p= productRepository.findById(prodid).get();
		if(p!=null)
		{
			p.setProductName(p.getProductName());
			p.setProductPrice(p.getProductPrice());
            p.setStock(p.getStock());
            p.setStore(p.getStore());
 
            		}
		return productRepository.save(p);
	


	}

	@Override
	public String deleteProduct(int prodid) {
		Product p= productRepository.findById(prodid).get();
		if(p!=null)
		{
			productRepository.delete(p);
		}

		return " The data is deleted";
		
		// TODO Auto-generated method s
		
	}

	@Override
	public List<Product> getAllProducts() {
		// TODO Auto-generated method stub
		return productRepository.findAll();
	}

	@Override
	public Product getProductById(int prodid) throws ResourceNotFoundException{
		// TODO Auto-generated method s
		Optional<Product> p= productRepository.findById(prodid);
		Product prods ;
		if(p.isPresent())
		{
		prods=p.get();
		}
		else
		{
			throw new  ResourceNotFoundException("Product", "prodid", prodid);
		}
		return prods;
	}

	@Override
	public String AssignStoreToProduct(int proid, int storeid) {
		Product p= productRepository.findById(proid).get();
		Store s=storeRepository.findById(storeid).get();
		p.setStore(s);

	List<Product> products= new ArrayList();
	products.add(p);
	s.setProducts(products);
	productRepository.save(p);
	
	
		// TODO Auto-generated method stub
		return "store id saved successfully";
	}

	@Override
	public String OrderProduct(int proId, OrderDetails orderDetails) {
		Product p= productRepository.findById(proId).get();
		int totalamt = 0;

		if(p!=null)
		{
			
			 totalamt=(orderDetails.getQuantity()*p.getProductPrice());
			orderDetails.setTotalAmount(totalamt);
			List<Product> products= new ArrayList<>();
			products.add(p);
			orderDetails.setProduct(products);
			p.setStock(p.getStock()-orderDetails.getQuantity());
			productRepository.save(p);
			orderRepository.save(orderDetails);
			
			
			
			
		}
		// TODO Auto-generated method stub
		return "Order  placed successfully!! your total amount is "+totalamt+"order will be delivered within 7 days";
	}

	@Override
	public String OrderCancel(int orderId) {
		  // 1. Check if the order is older than 7 days.
        OrderDetails order = orderRepository.findById(orderId)
            .orElseThrow(() -> new ResourceNotFoundException("Order", "id", orderId));
        
        LocalDate orderDate = order.getOrderDate();
        LocalDate currentDate = LocalDate.now();
        long daysBetween = ChronoUnit.DAYS.between(orderDate, currentDate);
        
        if (daysBetween >= 7) {
            throw new OrderCancellationException("Order cannot be canceled after 7 days.");
        }
        // 2. After canceling, increase the stock.
        List<Product> products = order.getProduct();
        for (Product product : products) {
            product.setStock(product.getStock() + order.getQuantity());
            productRepository.save(product);
        }

        // 3. Now, you can safely cancel the order.
        orderRepository.delete(order);

        return "Order canceled successfully.";

        

		
	}

}
