package com.anudip.ecom.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.anudip.ecom.entity.OrderDetails;
import com.anudip.ecom.entity.Product;
import com.anudip.ecom.service.ProductService;


@Component
@RestController
@RequestMapping("/")
public class ProductController {
	@Autowired    // perform the dependency injection
	ProductService productService;
	
	@GetMapping("/get")
	public List<Product>  getAllProuduct()
	{
		return productService.getAllProducts();
	}
	
	@PostMapping("/post")   // which is going to add the data into the database
	public  Product addProduct(@RequestBody Product prod) {
		
		return productService.createProduct(prod);
	}
	
	@PutMapping("/update")   //which is going to update the data
  public Product update(@RequestHeader int  id , @RequestBody Product prod ) {
		
		return productService.updateProduct(prod, id);
	}
	@DeleteMapping("/delete")   // delete  the data into database
	public String delete(@RequestHeader int id) {
		productService.deleteProduct(id);
		return "data deleted";
	}

	
	@PostMapping("/assign/{sId}/{pId}")
	public String assignStoreToProduct(@PathVariable int pId, @PathVariable int sId)
	{
		productService.AssignStoreToProduct(pId, sId);
		
		
		return "store id added successfully";
	}
	@PostMapping("/order/{pId}")
	public String PlaceOrder(@PathVariable int pId ,@RequestBody OrderDetails ordertails)
	{
		productService.OrderProduct(pId, ordertails);
		return "Order Placed Succcessfully";
		
	}

	
	@GetMapping("/getbyid/{pId}")
	public Product getProuductById(@PathVariable int pId)
	{
		return productService.getProductById(pId);
		
	}
	@DeleteMapping("/cancelorder/{id}")   // delete  the data into database
	public String cancelOrder(@PathVariable int id) {
		productService.OrderCancel(id);
		return "data deleted";
	}

	
}
