package com.anudip.ecom.exception;

public class OrderCancellationException extends RuntimeException
{

	public OrderCancellationException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}
	
}
