package com.anudip.ecom.serviceimpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.anudip.ecom.entity.Customer;
import com.anudip.ecom.repository.CustomerRepository;
import com.anudip.ecom.service.CustomerService;

@Service
public class CustomerServiceImpl implements CustomerService{
	
	@Autowired
	private CustomerRepository customerrepository;

	@Override
	public Customer getCustomer(int id) {
		// TODO Auto-generated method stub
		return customerrepository.findById(id).get();
	}

	@Override
	public List<Customer> getAllCustomers() {
		// TODO Auto-generated method stub
		return customerrepository.findAll();
	}

	@Override
	public Customer insertData(Customer customersData) {
		// TODO Auto-generated method stub
		return customerrepository.save(customersData);
	}

	@Override
	public Customer updateCustomer(Customer updateData, int id) {
		// TODO Auto-generated method stub
		
		Customer customerdata= customerrepository.findById(id).get();
		
		customerdata.setAddress(updateData.getAddress());
		customerdata.setAge(updateData.getAge());
		customerdata.setEmail(updateData.getEmail());
		customerdata.setName(updateData.getName());
		return customerrepository.save(customerdata);
	}

	@Override
	public String deleteCustomer(int id) {
		// TODO Auto-generated method stub
		 customerrepository.deleteById(id);
		
		return "Data has been deleted id ="+id;
	}

	@Override
	public boolean isCustomerExist(int id) {
		// TODO Auto-generated method stub
		return customerrepository.existsById(id);
	}

	

	

	
}
