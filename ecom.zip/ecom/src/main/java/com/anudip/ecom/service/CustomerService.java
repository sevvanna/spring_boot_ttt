package com.anudip.ecom.service;

import java.util.List;

import org.springframework.stereotype.Component;

import com.anudip.ecom.entity.Customer;

@Component
public interface CustomerService {
	
	Customer getCustomer(int id);
	
	List<Customer> getAllCustomers();
	
	Customer insertData(Customer customersData);
	
	Customer updateCustomer(Customer updateData,int id);
	
	String deleteCustomer(int id);
	
	boolean isCustomerExist(int id);
	
	

}
