package com.anudip.ecom.serviceimpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.anudip.ecom.entity.Product;
import com.anudip.ecom.entity.Store;
import com.anudip.ecom.repository.ProductRepository;
import com.anudip.ecom.repository.StoreRepository;
import com.anudip.ecom.service.ProductService;
import com.anudip.ecom.service.StoreService;

@Service
public class StoreServiceImpl implements StoreService  {
	
	@Autowired
	StoreRepository storeRepository;

	@Override
	public Store createStore(Store store) {
		// TODO Auto-generated method stub
		return storeRepository.save(store);
	}

	@Override
	public Store updateStore(Store store, int storeid) {
		
		Store s= storeRepository.findById(storeid).get();
		if(s!=null)
		{
		s.setStoreId(s.getStoreId());
		s.setStoreName(s.getStoreName());
 
            		}
		return storeRepository.save(s);
	
		
	}

	

	}
