package com.anudip.ecom.service;

import java.util.List;

import com.anudip.ecom.entity.OrderDetails;
import com.anudip.ecom.entity.Product;



public interface ProductService {
Product createProduct( Product prod);
Product updateProduct(Product prod,int prodid);
String deleteProduct(int prodid);
List<Product> getAllProducts();
Product getProductById(int prodid);
String AssignStoreToProduct(int proid,int storeid);
String OrderProduct(int orderId, OrderDetails orderDetails);
String OrderCancel(int orderId);
}
