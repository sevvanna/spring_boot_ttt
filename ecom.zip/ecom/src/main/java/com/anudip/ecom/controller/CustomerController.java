package com.anudip.ecom.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.anudip.ecom.entity.Customer;
import com.anudip.ecom.exception.CustomerNotFoundException;
import com.anudip.ecom.service.CustomerService;
import com.anudip.ecom.serviceimpl.CustomerServiceImpl;

@RestController

@CrossOrigin(origins = "http://localhost:4200")
@RequestMapping//(value = "/api")
public class CustomerController {
	
	@Autowired
	private CustomerService customerservice;		
	@GetMapping(value = "/getCustomer/{id}")
	public Customer getCustomer(@PathVariable int id) {
		boolean isCustomerExists=customerservice.isCustomerExist(id);
		if(isCustomerExists)
		{
			return customerservice.getCustomer(id);
	    }
		else
		{
			throw new CustomerNotFoundException();
		}
		
	}
	
	@GetMapping(value = "/getAllCustomers")
	public List<Customer> getAllCustomers(){
		return customerservice.getAllCustomers();
	}	
	@PostMapping(value="/addCustomer")
	public Customer addCustomer(@RequestBody Customer cutomer) {
		System.out.println("i am a java pers");
		return customerservice.insertData(cutomer);
	}	
	@PutMapping("/update/{id}")
	public Customer updateCustomer(@PathVariable int id,@RequestBody Customer customer) {
		boolean isCustomerExists=customerservice.isCustomerExist(id);
		if(isCustomerExists)
		{
		return customerservice.updateCustomer(customer, id);
	    }
		else
		{
			throw new CustomerNotFoundException();
		}
		}
	@DeleteMapping("/delete/{id}")
	public  String deleteCustomer(@PathVariable int id) {
		boolean isCustomerExists=customerservice.isCustomerExist(id);
		if(isCustomerExists)
		{
			return customerservice.deleteCustomer(id);
	    }
		else
		{
			throw new CustomerNotFoundException();
		}
		
	}	
	
}
