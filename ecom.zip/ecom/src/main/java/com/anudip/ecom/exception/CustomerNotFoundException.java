package com.anudip.ecom.exception;

public class CustomerNotFoundException extends RuntimeException
{
	private static final long serialVersionUID = 1L;
}
