package com.anudip.ecom.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.anudip.ecom.entity.Product;
import com.anudip.ecom.entity.Store;
import com.anudip.ecom.service.ProductService;
import com.anudip.ecom.service.StoreService;


@Component
@RestController
@RequestMapping("/")
public class StoreController {
	@Autowired    // perform the dependency injection
	StoreService storeService;
	
	
	@PostMapping("/add")   // which is going to add the data into the database
	public  Store addStore(@RequestBody Store store) {
		
		return storeService.createStore(store);
	}
	
	

}
