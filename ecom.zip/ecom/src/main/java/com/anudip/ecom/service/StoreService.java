package com.anudip.ecom.service;

import java.util.List;

import com.anudip.ecom.entity.Product;
import com.anudip.ecom.entity.Store;

public interface StoreService {
Store createStore( Store store);
Store updateStore(Store store,int storeid);

}
