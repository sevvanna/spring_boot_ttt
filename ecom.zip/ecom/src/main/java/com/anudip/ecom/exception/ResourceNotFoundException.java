package com.anudip.ecom.exception;

public class ResourceNotFoundException extends RuntimeException {
	private static final long serialVersionUID = 1L;

	public String getResourceName() {
		return ResourceName;
	}
	public void setResourceName(String resourceName) {
		ResourceName = resourceName;
	}
	public String getFieldName() {
		return FieldName;
	}
	public ResourceNotFoundException(String resourceName, String fieldName, Object fieldValue) {
		super(String.format("%s not found with %s:'%s'",resourceName,resourceName,fieldValue));
		ResourceName = resourceName;
		FieldName = fieldName;
		FieldValue = fieldValue;
	}
	public void setFieldName(String fieldName) {
		FieldName = fieldName;
	}
	public Object getFieldValue() {
		return FieldValue;
	}
	public void setFieldValue(Object fieldValue) {
		FieldValue = fieldValue;
	}
	private String ResourceName;
	private String FieldName;
	private Object FieldValue;

}
