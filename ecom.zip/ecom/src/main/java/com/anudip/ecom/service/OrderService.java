package com.anudip.ecom.service;

import java.util.List;

import com.anudip.ecom.entity.Product;
import com.anudip.ecom.entity.Store;

public interface OrderService {

}
//first complete all crud operations for store
//create cancelProduct() method where the logic will be
//1.after 7days of order, can not be cancelled
//2.after cancel,the stock again will going to increase
//3.Throw exception where you have invoke findById() method