package com.anudip.ecom;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OnlineSaleApplicationTests {

	@Test
	void contextLoads() {
	}

}
